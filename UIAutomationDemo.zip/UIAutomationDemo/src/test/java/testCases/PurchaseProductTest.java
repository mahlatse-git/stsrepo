package testCases;

import Base.BaseClass;
import PageObjects.*;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class PurchaseProductTest extends BaseClass{
    LoginPage loginPage;
    AddToCartPage addToCartPage;
    ViewCartPage viewCartPage;
    CheckOutPage checkOutPage;
    ThankYouPage thankYouPage;
    LogOutPage logOutPage;
    @DataProvider(name = "loginData")
    public Object[][] provideLoginData() {
        return new Object[][] {
                { "standard_user", "secret_sauce" }
        };
    }

    @Test(priority = 1,dataProvider = "loginData")
    public void loginIntoECommenceSite(String username,String password){
        try {
            loginPage = new LoginPage(driver);
            loginPage.verifyLoginPageIsDisplayed();
            loginPage.enterUsername(username);
            loginPage.enterPassword(password);
            loginPage.clickLogin();
            loginPage.verifyProductsHomeIsDisplayed();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test(dependsOnMethods = "loginIntoECommenceSite")
    public void navigateToProductsAndAddProducts() {
        try {
            addToCartPage = new AddToCartPage(driver);
            addToCartPage.clickAddFirstProductToCart();
            addToCartPage.clickAddSecondProductToCart();
            addToCartPage.verifyIfAddedProductsShowValidNumber();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test(dependsOnMethods = "navigateToProductsAndAddProducts")
    public void navigateToViewCart() {
        try {
           viewCartPage = new ViewCartPage(driver);
            viewCartPage.clickCartIcon();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test(dependsOnMethods = "navigateToViewCart")
    public void navigateToCheckout() {
        try {
            String firstName = "Mahlatse";
            String lastName = "Moneiwa";
            String zipCode = "0007";

            checkOutPage = new CheckOutPage(driver);
            checkOutPage.clickCheckout();
            checkOutPage.enterCheckOutInformation(firstName, lastName, zipCode);
            checkOutPage.verifyCheckOutOverviewAndFinish();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    @Test(dependsOnMethods = "navigateToCheckout")
    public void navigateToThankYouAndVerifyMessage(){
        try {
            thankYouPage = new ThankYouPage(driver);
            thankYouPage.verifySuccessfulOrder();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test(dependsOnMethods = "navigateToThankYouAndVerifyMessage")
    public void navigateToMenuAndLogout(){
        try {
            logOutPage = new LogOutPage(driver);
            logOutPage.clickMenuAndLogout();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

}
