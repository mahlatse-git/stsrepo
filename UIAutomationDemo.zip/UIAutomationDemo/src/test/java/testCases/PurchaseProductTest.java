package testCases;

import Base.BaseClass;
import PageObjects.*;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PurchaseProductTest extends BaseClass {
    WebDriver driver;

    @DataProvider(name = "loginData")
    public Object[][] provideLoginData() {
        return new Object[][] {
                { "standard_user", "secret_sauce" }
        };
    }
    @Test(priority = 1, dataProvider = "loginData")
    public void loginIntoECommenceSite(String username,String password){
        try {
            LoginPage loginPage = new LoginPage(driver);
            if (loginPage.verifyLoginPageIsDisplayed()) {
                loginPage.enterUsername(username);
                loginPage.enterPassword(password);
                loginPage.clickLogin();
                loginPage.verifyProductsHomeIsDisplayed();
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test(dependsOnMethods = "loginIntoECommenceSite" )
    public void navigateToProductsAndAddProducts() {
        try {
            AddToCartPage addToCartPage = new AddToCartPage(driver);
            addToCartPage.clickAddFirstProductToCart();
            addToCartPage.clickAddSecondProductToCart();
            addToCartPage.verifyIfAddedProductsShowValidNumber();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test(dependsOnMethods = "navigateToProductsAndAddProducts")
    public void navigateToViewCart() {
        try {
            ViewCartPage viewCartPage = new ViewCartPage(driver);
            viewCartPage.clickCartIcon();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test(dependsOnMethods = "navigateToViewCart")
    public void navigateToCheckout() {
        try {
            String firstName = "Mahlatse";
            String lastName = "Moneiwa";
            String zipCode = "0007";

            CheckOutPage checkOutPage = new CheckOutPage(driver);
            checkOutPage.enterCheckOutInformation(firstName, lastName, zipCode);
            checkOutPage.verifyCheckOutOverviewAndFinish();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    @Test(dependsOnMethods = "navigateToCheckout")
    public void navigateToMenuAndLogout(){
        try {
            ThankYouPage thankYouPage = new ThankYouPage(driver);
            thankYouPage.verifySuccessfulOrder();
            thankYouPage.clickMenuAndLogout();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

}
