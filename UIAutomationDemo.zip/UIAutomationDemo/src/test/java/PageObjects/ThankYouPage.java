package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class ThankYouPage {
    WebDriver driver;
    BaseClass baseClass;

    @FindBy(xpath = "//span[text()='Checkout: Complete!']")
    private WebElement checkOutCompleteLabel;

    @FindBy(xpath = "//h2[text()='Thank you for your order!']")
    private WebElement thankYouMessage;

    public ThankYouPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
        baseClass = new BaseClass();
    }

    public  void verifySuccessfulOrder(){
        String expectedSuccessMessage = "Thank you for your order!";
        String actualMessageDisplayed = thankYouMessage.getText();

        baseClass.dynamicWait(checkOutCompleteLabel);
        Assert.assertEquals(actualMessageDisplayed,expectedSuccessMessage);
    }


}
