package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class ThankYouPage {
    WebDriver driver;
    By checkOutCompleteLabel = By.xpath("//span[text()='Checkout: Complete!']");
    By thankYouMessage = By.xpath("//h2[text()='Thank you for your order!']");
    By menuButton = By.xpath("//button[@id='react-burger-menu-btn']");
    By logoutLink = By.xpath("//a[@id='logout_sidebar_link']");

    public ThankYouPage(WebDriver driver){
        this.driver = driver;
    }

    public  void verifySuccessfulOrder(){
        String expectedSuccessMessage = "Thank you for your order!";
        String actualMessageDisplayed = driver.findElement(thankYouMessage).getText();

        BaseClass.dynamicWait(checkOutCompleteLabel);
        Assert.assertEquals(actualMessageDisplayed,expectedSuccessMessage);
    }

    public void clickMenuAndLogout(){
        driver.findElement(menuButton).click();
        BaseClass.dynamicWait(logoutLink);
        driver.findElement(logoutLink).click();
    }

}
