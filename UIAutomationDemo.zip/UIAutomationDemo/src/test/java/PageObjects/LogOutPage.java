package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LogOutPage {
    WebDriver driver;
    By menuButton = By.xpath("//button[@id='react-burger-menu-btn']");
    By logoutLink = By.xpath("//a[@id='logout_sidebar_link']");

    public LogOutPage(WebDriver driver){
        this.driver = driver;
    }
    public void clickMenuAndLogout() throws InterruptedException {
        BaseClass.dynamicWait(menuButton);
        driver.findElement(menuButton).click();
        BaseClass.dynamicWait(logoutLink);
        Thread.sleep(1000);
        driver.findElement(logoutLink).click();
    }
}
