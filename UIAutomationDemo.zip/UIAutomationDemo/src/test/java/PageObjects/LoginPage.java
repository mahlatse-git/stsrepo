package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage {
    WebDriver driver;
    
   @FindBy(xpath = "//div[text()='Swag Labs']")
   private WebElement loginLogoLabel;

    @FindBy(id = "user-name")
    private WebElement usernameTextField;

    @FindBy(id = "password")
    private WebElement passwordTextField;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    @FindBy(xpath = "//span[@class='title']")
    private WebElement productsLabel;

    public LoginPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }


    public void verifyLoginPageIsDisplayed(){
        BaseClass.dynamicWait(loginLogoLabel);
        String expectedLogoName = "Swag Labs";
        String actualLogoName = loginLogoLabel.getText();

        Assert.assertEquals(actualLogoName,expectedLogoName);
    }

    public void enterUsername(String username) {
        usernameTextField.sendKeys(username);
    }
    public void enterPassword(String password){
        passwordTextField.sendKeys(password);
    }

    public void clickLogin(){
        loginButton.click();
    }

    public void verifyProductsHomeIsDisplayed(){
        String expectedLabel = "Products";
        String actualLabel =productsLabel.getText();
        Assert.assertEquals(actualLabel,expectedLabel);
    }
}
