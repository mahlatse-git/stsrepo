package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage {
    WebDriver driver;

   By loginLogoLabel = By.xpath( "//div[text()='Swag Labs']");
   By usernameTextField = By.xpath("//input[@id='user-name']");
   By passwordTextField = By.id("password");
   By loginButton = By.id("login-button");
   By productsLabel = By.xpath("//span[@class='title']");

    public LoginPage(WebDriver driver){
        this.driver = driver;
    }


    public void verifyLoginPageIsDisplayed(){
        BaseClass.dynamicWait(loginLogoLabel);
        String expectedLogoName = "Swag Labs";
        String actualLogoName = driver.findElement(loginLogoLabel).getText();

        Assert.assertEquals(actualLogoName,expectedLogoName);
    }

    public void enterUsername(String username) {
        driver.findElement(usernameTextField).sendKeys(username);
    }
    public void enterPassword(String password){
        driver.findElement(passwordTextField).sendKeys(password);
    }

    public void clickLogin(){
        driver.findElement(loginButton).click();
    }

    public void verifyProductsHomeIsDisplayed(){
        String expectedLabel = "Products";
        String actualLabel = driver.findElement(productsLabel).getText();
        Assert.assertEquals(actualLabel,expectedLabel);
    }
}
