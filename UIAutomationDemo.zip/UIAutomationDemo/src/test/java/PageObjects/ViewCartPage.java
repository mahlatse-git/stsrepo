package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ViewCartPage {
    WebDriver driver;


    By viewCartIcon = By.xpath( "//a[@class='shopping_cart_link']");
    By checkOutButton = By.xpath( "//button[@id='checkout']");



    public ViewCartPage(WebDriver driver){
        this.driver = driver;
    }

    public void clickCartIcon(){
        driver.findElement(viewCartIcon).click();
        BaseClass.dynamicWait(checkOutButton);
    }

}
