package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ViewCartPage {
    WebDriver driver;
    BaseClass baseClass;
    @FindBy(xpath = "//a[@class='shopping_cart_link']")
    private WebElement viewCartIcon;

    @FindBy(id = "checkout")
    private WebElement checkOutButton;


    public ViewCartPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
        baseClass = new BaseClass();
    }

    public void clickCartIcon(){
        viewCartIcon.click();
        baseClass.dynamicWait(checkOutButton);
    }

}
