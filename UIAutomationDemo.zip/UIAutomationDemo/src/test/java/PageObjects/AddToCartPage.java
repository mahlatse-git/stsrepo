package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;


public class AddToCartPage {
    WebDriver driver;
    public String firstProductPrice;
    public String secondProductPrice;

    By firstProductNameLabel = By.xpath("//div[text()='Sauce Labs Backpack']");
    By firstProductPriceLabel = By.xpath("//div[text()='29.99']");
    By secondProductNameLabel = By.xpath( "//div[text()='Sauce Labs Bike Light']");
    By secondProductPriceLabel = By.xpath("//div[text()='9.99']");
    By addFirstProductButton = By.id( "add-to-cart-sauce-labs-backpack");
    By addSecondProductButton = By.id( "add-to-cart-sauce-labs-bike-light");

    By totalNumberOfAddedProducts = By.xpath("//span[text()='2']");

    public AddToCartPage(WebDriver driver){
        this.driver = driver;
    }

    public void clickAddFirstProductToCart(){
        BaseClass.dynamicWait(firstProductNameLabel);
        firstProductPrice = driver.findElement(firstProductPriceLabel).getText();
       driver.findElement(addFirstProductButton).click();
    }

    public void clickAddSecondProductToCart(){
        BaseClass.dynamicWait(secondProductNameLabel);
        secondProductPrice = driver.findElement(secondProductPriceLabel).getText();

        driver.findElement(addSecondProductButton).click();
    }

    public void verifyIfAddedProductsShowValidNumber(){
        String expectedNumberOfAddedProducts = "2";
        String actualNumberOfAddedProducts = driver.findElement(totalNumberOfAddedProducts).getText();

        Assert.assertEquals(actualNumberOfAddedProducts,expectedNumberOfAddedProducts);
    }

}
