package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;


public class AddToCartPage {
    WebDriver driver;

    public String firstProductPrice;
    public String secondProductPrice;

    @FindBy(xpath = "//div[text()='Sauce Labs Backpack']")
    private WebElement firstProductNameLabel;

    @FindBy(xpath = "//div[text()='29.99']")
    private WebElement firstProductPriceLabel;

    @FindBy(xpath = "//div[text()='Sauce Labs Bike Light']")
    private WebElement secondProductNameLabel;

    @FindBy(xpath = "//div[text()='9.99']")
    private WebElement secondProductPriceLabel;

    @FindBy(id = "add-to-cart-sauce-labs-backpack")
    private WebElement addFirstProductButton;

    @FindBy(id = "add-to-cart-sauce-labs-bike-light")
    private WebElement addSecondProductButton;

    @FindBy(xpath = "//span[text()='2']")
    private WebElement totalNumberOfAddedProducts;

    public AddToCartPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);

    }

    public void clickAddFirstProductToCart(){
        BaseClass.dynamicWait(firstProductNameLabel);
        firstProductPrice = firstProductPriceLabel.getText();
        addFirstProductButton.click();
    }

    public void clickAddSecondProductToCart(){
        BaseClass.dynamicWait(secondProductNameLabel);
        secondProductPrice = secondProductPriceLabel.getText();

        addSecondProductButton.click();
    }


    public void verifyIfAddedProductsShowValidNumber(){
        String expectedNumberOfAddedProducts = "2";
        String actualNumberOfAddedProducts = totalNumberOfAddedProducts.getText();

        Assert.assertEquals(actualNumberOfAddedProducts,expectedNumberOfAddedProducts);
    }

}
