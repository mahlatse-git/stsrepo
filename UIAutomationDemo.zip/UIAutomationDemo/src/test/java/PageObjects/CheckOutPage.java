package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckOutPage {
    WebDriver driver;

    By checkOutInformationLabel = By.xpath( "//span[text()='Checkout: Your Information']");
    By firstNameTextField = By.id("first-name");
    By lastNameTextField = By.id("last-name");
    By zipCodeTextField = By.id("postal-code");
    By continueButton = By.id("continue");

    By checkOutOverViewLabel = By.xpath("//span[text()='Checkout: Overview']");
    By finishButton = By.id("finish");

    public CheckOutPage(WebDriver driver){
        this.driver = driver;
    }

    public void enterCheckOutInformation(String firstName, String lastName,String zipCode){
        BaseClass.dynamicWait(checkOutInformationLabel);
        driver.findElement(firstNameTextField).sendKeys(firstName);
        driver.findElement(lastNameTextField).sendKeys(lastName);
        driver.findElement(zipCodeTextField).sendKeys(zipCode);
        driver.findElement(continueButton).click();
    }

    public void verifyCheckOutOverviewAndFinish(){
        BaseClass.dynamicWait(checkOutOverViewLabel);
        driver.findElement(finishButton).click();
    }
}
