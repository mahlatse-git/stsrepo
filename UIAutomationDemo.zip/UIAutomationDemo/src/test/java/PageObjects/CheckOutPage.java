package PageObjects;

import Base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckOutPage {
    WebDriver driver;

    @FindBy(xpath = "//span[text()='Checkout: Your Information']")
    private WebElement checkOutInformationLabel;

    @FindBy(id = "first-name")
    private WebElement firstNameTextField;

    @FindBy(id = "last-name")
    private WebElement lastNameTextField;

    @FindBy(id = "postal-code")
    private WebElement zipCodeTextField;

    @FindBy(id = "continue")
    private WebElement continueButton;

    @FindBy(id = "checkout")
    private WebElement checkOutButton;

    @FindBy(xpath = "//span[text()='Checkout: Overview']")
    private WebElement checkOutOverViewLabel;

    @FindBy(id = "finish")
    private WebElement finishButton;

    public CheckOutPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    public void clickCheckout(){
        BaseClass.dynamicWait(checkOutButton);
        checkOutButton.click();
    }
    public void enterCheckOutInformation(String firstName, String lastName,String zipCode){
        BaseClass.dynamicWait(checkOutInformationLabel);
        firstNameTextField.sendKeys(firstName);
        lastNameTextField.sendKeys(lastName);
        zipCodeTextField.sendKeys(zipCode);
        continueButton.click();
    }

    public void verifyCheckOutOverviewAndFinish() {
        BaseClass.dynamicWait(checkOutOverViewLabel);
        BaseClass.scrollDown();
        if(BaseClass.verifyVisibleText(finishButton)) {
            finishButton.click();
        }
    }
}
