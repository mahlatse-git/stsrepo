package Base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import java.time.Duration;

import static Base.DriverManager.getDriver;
import static Base.DriverManager.setWebDriver;


public class BaseClass {
    protected WebDriver driver;
    @BeforeClass
    public void initSetup(){
        String baseURL = "https://www.saucedemo.com/";
        WebDriverManager.safaridriver().setup();
        SafariOptions options = new SafariOptions();

        driver = new SafariDriver(options);
        setWebDriver(driver);
        /*WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        driver = new ChromeDriver(options);**/

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

        driver.get(baseURL);
    }


    @AfterClass
    public void tearDown(){
        if(driver != null){
            driver.quit();
        }
    }

    public static boolean verifyVisibleText(WebElement el){
        return el.isDisplayed();
    }
    public static void dynamicWait(WebElement el){
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(el));
    }

    public static void scrollDown(){
        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("window.scrollBy(0,250)", "");
    }

}
