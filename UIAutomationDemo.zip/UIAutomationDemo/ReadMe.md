Web Automation POM Design Framework
===================================
Advantages of POM
1.Easy to Maintain
2.Easy to read
3.Modularized page objects/classes
4.Better Test Organization